import styled from 'styled-components';

export const Div = styled.div`
    position: relative
`;

